﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Signup : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        Random rd = new Random();
        TextBox11.Text = rd.Next().ToString();

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {


        DataConnect dt = new DataConnect(); //class name dataconnect.cs in App_Code\DataConnect.cs
        dt.openConnection();

        if (RadioButton1.Checked == true)
            TextBox12.Text = "Male";
        else
            TextBox12.Text = "Female";
        int k = dt.insupdel(" insert into Customer values('" + TextBox11.Text + " ' , '" + TextBox1.Text + " ','" + TextBox2.Text + " ' , '" + TextBox12.Text+ " ','" + DropDownList1.SelectedValue + " ' , '" + TextBox5.Text + " ','" + TextBox6.Text + " ' , '" + TextBox7.Text + " ' , '" + TextBox8.Text + " ' , '" + TextBox10.Text + "')");
        if (k > 0)
            Label1.Text = "New Account created !!!";
        else
            Label1.Text = "Some error occured!!! Please try again...";
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = "";
        TextBox9.Text = "";
        TextBox10.Text = "";
        TextBox1.Focus();
        dt.closeConnection();




    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {

    }
    protected void TextBox11_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
}