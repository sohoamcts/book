﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    SqlDataReader dr1;
    
    DataConnect dt = new DataConnect();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Signup.aspx");
    }
    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        if (TextBox1.Text == "admin@gmail.com" && TextBox2.Text == "admin" && TextBox3.Text == "password")
            Response.Redirect("adminfunction.aspx");
    //    else if ()
      //  {
        dt.openConnection();
        dt.SqlQuery(" select * from Customer where email='"+ TextBox1.Text +"'and uname='" + TextBox2.Text + "' and pw='" + TextBox3.Text + "'");
        dr1 = dt.getQuery;
        
        if (dr1.HasRows)
        {
            dr1.Close();
           Label2.Text="login succesfull";
           Session["ss"] = TextBox2.Text;
           dt.SqlQuery("select ID from Customer where uname like'" + TextBox2.Text + "'");
           dr1 = dt.getQuery;
            if(dr1.Read())
            {
                int id = int.Parse(dr1.GetValue(0).ToString());
             Session["cid"] = id.ToString();
             Response.Redirect("Default.aspx");
            }
        }
        else
        {
            Label2.Text = "LOGIN FAILED";
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
        }
        dr1.Close();
        dt.closeConnection();
       
        
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Signup.aspx");
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Signup.aspx");
    }
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("HOME.aspx");
    }
}