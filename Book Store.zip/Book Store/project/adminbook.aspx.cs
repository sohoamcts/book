﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;

public partial class adminbook : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename='C:\\Users\\Babi\\Documents\\Visual Studio 2010\\WebSites\\project\\App_Data\\Database.mdf';Integrated Security=True;User Instance=True");
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("adminfunction.aspx");
    }
   
    protected void Button2_Click(object sender, EventArgs e)
    {

        DataConnect dt = new DataConnect(); //class name dataconnect.cs in App_Code\DataConnect.cs
        dt.openConnection();
        int k = dt.insupdel("update book set price='" + TextBox3.Text + "' , pages='" + TextBox5.Text + "' where isbn=" + TextBox1.Text);

        if (k > 0)
            Label9.Text = " update successful ";
        else
            Label9.Text = " error in updation";
        dt.closeConnection();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {

        DataConnect dt = new DataConnect(); //class name dataconnect.cs in App_Code\DataConnect.cs
        dt.openConnection();
        int k = dt.insupdel(" delete from book where isbn= " + TextBox1.Text);
        if (k > 0)
            Label9.Text = " deleted ";
        else
            Label9.Text = " error in deletion";
        dt.closeConnection();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {

        if (FileUpload1.HasFile)
        {
            string str = FileUpload1.FileName;
            FileUpload1.PostedFile.SaveAs(Server.MapPath(".") + "//book//" + str);
            string path = "~//book//" + str.ToString();
            con.Open();
            SqlCommand cmd = new SqlCommand(" insert into book values ('" + TextBox1.Text + "' ,'" + TextBox2.Text + "' ,'" + TextBox3.Text + "' ,'" + path + "' ,'" + TextBox5.Text + "' ,'" + TextBox6.Text + "' ,'" + TextBox7.Text + "' ,'" + TextBox8.Text + "' )", con);
            cmd.ExecuteNonQuery();
            con.Close();
            Label9.Text = " INSERT SUCCESSFUL";

        }

        else
            Label9.Text = " error in insertion";



    }
 
}