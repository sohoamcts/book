﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class adminauthor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DataConnect dt = new DataConnect(); //class name dataconnect.cs in App_Code\DataConnect.cs
        dt.openConnection();
        int k = dt.insupdel(" insert into author values('" + TextBox1.Text + " ','" + TextBox2.Text + " ')");
        if (k > 0)
            Label4.Text = " insert success ";
        else
            Label4.Text = " error in insertion";
        dt.closeConnection();

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        DataConnect dt = new DataConnect(); //class name dataconnect.cs in App_Code\DataConnect.cs
        dt.openConnection();
        int k = dt.insupdel(" delete from author where authorid= " + TextBox1.Text);
        if (k > 0)
            Label4.Text = " deleted ";
        else
           Label4.Text = " error in deletion";
        dt.closeConnection();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        DataConnect dt = new DataConnect(); //class name dataconnect.cs in App_Code\DataConnect.cs
        dt.openConnection();
        int k = dt.insupdel("update author set authorid='" + TextBox1.Text + "' , authorname='" + TextBox2.Text + "'  where authorid=" + TextBox1.Text);

        if (k > 0)
           Label4.Text = " update successful ";
        else
           Label4.Text = " error in updation";
        dt.closeConnection();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("adminfunction.aspx");
    }
}