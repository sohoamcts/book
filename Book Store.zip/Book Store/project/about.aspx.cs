﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class about : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = " The Online Book Store (OBS) application enables vendors to set uponline book stores, customers to browse through the books, and asystem administrator to approve and reject requests for new books andmaintain lists of book categories.Also on the agenda is designing an online book site tomanage the items in the store and also help customers purchasethem online without having to visit the shop physically.Our online book store will use the internet asthe sole method for selling books to its consumers. The consumer will be in complete control of his/hershopping experience by using the unique storefront concept.Today the internet and its boom have created a new economicscenario that not only stresses on the classical concept of the product but also on the modern concept of service. It is thislevel of service that dictates whether a commercial venture willsucceed or not in the market. To provide a high accessibility of servicewe will design the online shopping website, so that potentialcustomers need not go to a physical shop to buy books. They just needto online to complete their purchases.Most current systems have a physical foundation that is the rootcause to quite a number of problems.";
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
}