﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class payment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename='C:\\Users\\Babi\\Documents\\Visual Studio 2010\\WebSites\\project\\App_Data\\Database.mdf';Integrated Security=True;User Instance=True");
        
        String mm = Session["ss"].ToString();
        Label1.Text = mm;
        

    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        TextBox3.Text = GridView1.SelectedRow.Cells[1].Text;
        TextBox4.Text = GridView1.SelectedRow.Cells[2].Text;
        TextBox5.Text = GridView1.SelectedRow.Cells[3].Text;
        TextBox6.Text = GridView1.SelectedRow.Cells[4].Text;
        TextBox7.Text = GridView1.SelectedRow.Cells[5].Text;
        Session["pid"] = TextBox3.Text;
        
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        DataConnect dt = new DataConnect();
        dt.openConnection();
        
        LinkButton btn = sender as LinkButton;
        String crd = btn.Text;
        TextBox1.Text = crd;

        int card = dt.insupdel(" insert into payment1 values('" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox1.Text + "')");
        int dcard = dt.insupdel("delete from payment where paymentid like '" + TextBox3.Text + "'");
       // int d = dt.insupdel(" delete from order where orderid like '" + TextBox4.Text + "'");
        dt.closeConnection();
        Response.Redirect("card.aspx");
    }
    
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        DataConnect dt = new DataConnect();
        dt.openConnection();
        
        LinkButton btn = sender as LinkButton;
        String cod = btn.Text;
        TextBox1.Text = cod;
      
        int codd = dt.insupdel(" insert into payment1 values('" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox1.Text + "')");
        int dcodd = dt.insupdel("delete from payment where paymentid like '" + TextBox3.Text + "'");
        dt.closeConnection();

        Response.Redirect("cod.aspx");
    }


    
}