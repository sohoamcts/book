﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class cart : System.Web.UI.Page

{
    
    protected void Page_Load(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename='C:\\Users\\Babi\\Documents\\Visual Studio 2010\\WebSites\\project\\App_Data\\Database.mdf';Integrated Security=True;User Instance=True");
        String mm = Session["ss"].ToString();
        Label1.Text = mm;

        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("selectedbookdetails.aspx");
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox2.Text = GridView1.SelectedRow.Cells[4].Text;
        TextBox4.Text = GridView1.SelectedRow.Cells[1].Text;
        TextBox5.Text = GridView1.SelectedRow.Cells[6].Text;
        TextBox6.Text = GridView1.SelectedRow.Cells[2].Text;
        TextBox7.Text = GridView1.SelectedRow.Cells[5].Text;
      
    }
    
    protected void LinkButton5_Click(object sender, EventArgs e)
    {

        DataConnect dt = new DataConnect();
        dt.openConnection();
        int k = dt.insupdel("delete from order where orderid like '"+TextBox4.Text+"'");
        dt.closeConnection();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        
    }
    protected void LinkButton6_Click(object sender, EventArgs e)
    {

        
        Random rd = new Random();
        TextBox3.Text = rd.Next().ToString();
        Session["oid"] = TextBox4.Text;
        
        DataConnect dt = new DataConnect();
        dt.openConnection();
        int t = dt.insupdel(" insert into payment values('"+TextBox3.Text+"','"+TextBox4.Text+"','"+TextBox5.Text +"','"+TextBox6.Text+"','"+TextBox7.Text+"')" );
        
        Response.Redirect("payment.aspx");
        dt.closeConnection();
    }
    
    

}