﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class selectedbookdetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename='C:\\Users\\Babi\\Documents\\Visual Studio 2010\\WebSites\\project\\App_Data\\Database.mdf';Integrated Security=True;User Instance=True");
        String mm = Session["ss"].ToString();
        Label2.Text = mm;
        String ccc = Session["cid"].ToString();
       // TextBox9.Text = Session["cid"].ToString();

        
        TextBox9.Text = ccc;
        Session["cid"] = TextBox9.Text;
        
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox4.Text = GridView1.SelectedRow.Cells[2].Text.Substring(0);
        TextBox8.Text = GridView1.SelectedRow.Cells[1].Text.Substring(0)
            ;
    }
       
           

    
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("category.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {


         
        String name = Session["til"].ToString();
        TextBox1.Text = name;
       

        Random rd = new Random();
        TextBox3.Text = rd.Next().ToString();
        int val1 = int.Parse(TextBox4.Text);

        int val2 = int.Parse(TextBox2.Text);
        int val3 = val2 * val1;
        TextBox5.Text = val3.ToString();

        DataConnect dt = new DataConnect(); //class name dataconnect.cs in App_Code\DataConnect.cs
        dt.openConnection();
        int z = dt.insupdel("select isbn from book where title like '"+ TextBox8.Text+"'");
        TextBox10.Text = z.ToString();
       // TextBox4.Text = "insert into order values('" + TextBox3.Text + "','" + TextBox1.Text + "','" + Label2.Text + "'," + val2 + ",'" + TextBox5.Text + "')";
        int k = dt.insupdel("insert into [order] values('" + TextBox3.Text + "','" + Label2.Text + "','"+TextBox10.Text+"',"+ val2 + ",'"+ TextBox1.Text +"','" + TextBox5.Text + "','" +TextBox9.Text +"')");
        int k1 = dt.insupdel("insert into [order1] values('" + TextBox3.Text + "','" + Label2.Text + "','" + TextBox10.Text + "'," + val2 + ",'" + TextBox1.Text + "','" + TextBox5.Text + "','" + TextBox9.Text + "')");
        Label3.Text = "Item has been added to cart successfully.Click VIEW CART";



        
            dt.closeConnection();

    }
    
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        DataConnect dt=new DataConnect();
        dt.openConnection();
        int p=dt.insupdel(" select * from [order] where uname like '" + Label2.Text+"'");
        Response.Redirect("cart.aspx");
        dt.closeConnection();
    }


    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox6_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox9_TextChanged(object sender, EventArgs e)
    {

    }
}