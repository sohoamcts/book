﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String nm = Session["lg"].ToString();
        TextBox2.Text = nm;
    }

    protected void titleLabel_Click(object sender, EventArgs e)
    {
        LinkButton btn = sender as LinkButton;
        String title = btn.Text;
        TextBox3.Text = title;

        Session["til"] = TextBox3.Text;

        Response.Redirect("~/selectedbookdetails.aspx?title=" + ((LinkButton)sender).Text);


    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
}