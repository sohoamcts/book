﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for DataConnect
/// </summary>
public class DataConnect
{
    private SqlConnection con = new SqlConnection();
    private SqlCommand com = new SqlCommand();
    private SqlDataReader dr;
    public DataConnect()
    {
        con.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename='C:\\Users\\Babi\\Documents\\Visual Studio 2010\\WebSites\\project\\App_Data\\Database.mdf';Integrated Security=True;User Instance=True";
    }
    public void openConnection()
    {
        con.Open();
    }
    public void SqlQuery(String q)
    {
        com.CommandText = q;
        com.Connection = con;
        dr = com.ExecuteReader();
    }
    public SqlDataReader getQuery
    {
        get
        {
            return dr;
        }
    }
    public int insupdel(String qu)
    {
        com.CommandText = qu;
        com.Connection = con;
        
        int v = com.ExecuteNonQuery();
        return v;
    }


    public void closeConnection()
    {
        con.Close();
    }
    public void closeDatareader()
    {
        dr.Close();
    }
    public void clearCommand()
    {
        com.Cancel();
    }
}

