﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class card : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String gh = Session["pid"].ToString();
        //TextBox3.Text = gh;
        Session["pid"] = gh;
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("card.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("card.aspx");
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("card.aspx");
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("OTP.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("payment.aspx");
    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
}