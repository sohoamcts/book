﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    // SqlDataReader dr1;
    DataConnect dt = new DataConnect();

    // Label l1;
    //TextBox t1;
    //Image img;
    // LinkButton b1;

    protected void Page_Load(object sender, EventArgs e)
    {
        String nm = Session["ss"].ToString();
        Label2.Text = nm;

      //  dt.openConnection();
        String iid = Session["cid"].ToString();
        TextBox6.Text = iid;
        Session["cid"] = TextBox6.Text;

       //int cid=dt.insupdel("select ID from Customer where uname ='"+Label2.Text+"'");
        
        //dr1=dt.getQuery;
        //while (dr1.Read())
        //{

        //    img = new Image();
        //    img.ImageUrl = dr1.GetValue(1).ToString();
        //    b1 = new LinkButton();
        //    b1.Text = dr1.GetValue(0).ToString();
        //    PlaceHolder1.Controls.Add(img);
        //    PlaceHolder1.Controls.Add(b1);


        //}
       

    }
    ////protected void b1_Click(object sender, EventArgs e)
    ////{
    ////    t1.Text = "Hello";
    ////}

    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
    {

        TextBox2.Text = Menu1.SelectedValue;
        Session["lg"] = TextBox2.Text.Trim();
        Response.Redirect("category.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
        Session["name"] = TextBox1.Text.Trim();

        Response.Redirect("searchbook.aspx");
    }

    protected void titleLabel_Click(object sender, EventArgs e)
    {
        LinkButton btn = sender as LinkButton;
        String title = btn.Text;
        TextBox4.Text = title;

        Session["til"] = TextBox4.Text;

        Response.Redirect("~/selectedbookdetails.aspx?title=" + ((LinkButton)sender).Text);
    }

    protected void TextBox6_TextChanged(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        DataConnect dt = new DataConnect();
        dt.openConnection();
        int p = dt.insupdel(" select * from [order] where uname like '" + Label2.Text + "'");
        Response.Redirect("cart.aspx");
        dt.closeConnection();
    }
}