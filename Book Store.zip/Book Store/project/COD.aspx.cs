﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class COD : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String cood = Session["ss"].ToString();
        Label2.Text = cood;
        String gh = Session["pid"].ToString();
        //TextBox3.Text = gh;
        Session["pid"] = gh;
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("print.aspx");
    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {

    }
}